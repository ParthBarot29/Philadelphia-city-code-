//this program gives you all the functionality in order to run the program 
// Team 3 work whole team did work on small parts and at end we merge 
//all the component in one file 



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.util.Date;


 class User 
{
    private String  FirstName;
    private String  LastName; 
    private double id;
    private Account Checking; 
    private Account Vacation;
    private Account Saving;
    
   
    public User(String firstName, String lastName, Account checking,
			Account vacation, Account saving) {
		super();
		FirstName = firstName;
		LastName = lastName;
		this.id = Math.random();
		Checking = checking;
		Vacation = vacation;
		Saving = saving;
	}
	public Account getChecking() {
		return Checking;
	}
	public void setChecking(Account checking) {
		Checking = checking;
	}
	public Account getVacation() {
		return Vacation;
	}
	public void setVacation(Account vacation) {
		Vacation = vacation;
	}
	public Account getSaving() {
		return Saving;
	}
	public void setSaving(Account saving) {
		Saving = saving;
	}
	public double getId() {
		return id;
	}
	
    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }
   

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }
	public String toString() {
		
		String s= "ID = "+id+"\nFirstName = " + FirstName + "\nLastName= " + LastName+"\n";
		s=s+"Balance: \nSaving: " + Saving +"\n";
		s=s+"Checking: " + Checking +"\n";
		s=s+"Vacation: " + Vacation +"\n";
		
		return s;
	}

	public void Deposit(double bal,Account type)
	{
		type.Deposit(bal);
		
	}
	public boolean Withdraw(double bal,Account type)
	{
		return type.Withdraw(bal);
	}
	public boolean Transfer(Account to, Account from,double am)
	{
		return from.Transfer(to, am);
		
	}
    
}


class Account {

	
	private double Balance;
	
	public Account(double b)
	{
		
		Balance =b;
		
	}
	
	public void setBalance(double bal) {
		 this.Balance=bal;
	}
     
	public double getbal() {
		return Balance;
	}
	
	
	public void Deposit(double bal) {
		this.Balance=this.Balance+bal;
		
	}
      
	public boolean Withdraw(double bal) {
		if(this.Balance-bal>=0)
		{
			this.Balance=this.Balance-bal;
			return true;
		}
		return false;
	}

    
	public boolean Transfer(Account to,double am) {
		 if(Withdraw(am))
		 {
			 to.Deposit(am);
			 return true;
		 }
			return false;
		
	}
	public String toString() {
		return "\n Balance  = " + this.Balance;
	}
	
	
	
}
 
class Transactions 
{
	ArrayList <String>Transactions;
	public Transactions()
	{
		Transactions= new ArrayList();
	}
	public void Deposit(User us,double bal,Account type)
	{
		us.Deposit(bal,type);
		MakeTrannAction(us.toString()+"\n has deposites" ,  bal);
	}
	public boolean Withdraw (User us,double bal,Account type)
	{
		if(us.Withdraw(bal,type)==true)
		{
			MakeTrannAction(us.toString()+"\n has withdraw" ,  bal);
			return true;
		}
		else
		{
				MakeTrannAction(us.toString()+" insuffuecent balance " ,  bal);
				return false;
		}
	}
	public boolean Transfer( User a,Account to, Account from,double amount)
	{
		 if(a.Transfer(to,from, amount)==true )
		 {
		      MakeTrannAction(a.toString()+" \nhas transferd  to "+a.toString() ,amount);
		      return true;
		 }
		 else
		 {
			 MakeTrannAction(a.toString()+" \nhas failed  t "+a.toString() ,amount);
			 return false;
		 }
	
	}
	public void seeAllTransaction()
	{
		for(String s:Transactions)
		{
			System.out.println(s);
		}
	}
	void MakeTrannAction(String info,double Amount)
	{
		 Calendar cal = Calendar.getInstance();
	        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
	       
	       
	        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	        Date date = new Date();
		
		String T= sdf.format(cal.getTime())+"\n"+dateFormat.format(date)+"\n"+info+" "+Amount+"$ \n";
		this.Transactions.add(T);
	
		
		
	}

}

public class IST242Team3Bank 
{
	 User us=null;
	 Transactions trans=null;
    public static void main(String[] args) 
	{
    	IST242Team3Bank  obj= new IST242Team3Bank();
	   	Scanner sc = new Scanner(System.in);
                String Fname ;
                String Lastname ;
                double c,s,v;
                System.out.println("Enter new user");
                System.out.print("Enter Firstname: ");
                Fname= sc.nextLine();
                 System.out.print("Enter lastname: ");
                Lastname = sc.nextLine();
                
                System.out.println("Enter amount for Saving account");
                s= sc.nextDouble();
                System.out.println("Enter amount for Checking account");
                c= sc.nextDouble();
                System.out.println("Enter amount for Vacation account");
                v= sc.nextDouble();
                
                Account checking= new Account(c);
                Account saving= new Account(s);
                Account vacation= new Account(v);
                obj.us=new  User(Fname, Lastname,checking,vacation,saving);
                obj.trans= new Transactions();
                System.out.println("User Information");
		    System.out.println(obj.us);
                    
		    
		    int choice=0;
		    do{
		    	printMenu();
		    	choice= sc.nextInt();
		    	int type=0;

	    		 double amount=0;
		    	switch(choice)
		    	{
		    	case 1:
		    		System.out.println("Select Account");
		    		 accountMenu();
		    		 type= sc.nextInt();
		    		 while(type <1 || type>3)
		    		 {
		    			accountMenu();
			    		 type= sc.nextInt();
		    		 }
		    		 System.out.println("Enter amount to deposit");
		    		 amount=sc.nextDouble();
		    		 obj.deposit(amount,type);
		    		 
		    		 break;
		    		 
		    	case 2:
		    		System.out.println("Select Account");
		    		 accountMenu();
		    		 type= sc.nextInt();
		    		 while(type <1 || type>3)
		    		 {
		    			accountMenu();
			    		 type= sc.nextInt();
		    		 }
		    		 System.out.println("Enter amount to Withdraw");
		    		 amount=sc.nextDouble();
		    		 obj.Withdraw(amount,type);
		    		 
		    		 break;
		    		 
		    	case 3:
		    		System.out.println("Select Account from which you want to tranfer");
		    		accountMenu();
		    		int type1= sc.nextInt();
		    		 while(type1 <1 || type1>3)
		    		 {
		    			accountMenu();
			    		 type1= sc.nextInt();
		    		 }
		    		 System.out.println("Select Account to which you want to tranfer");
			    		accountMenu();
			    		int type2= sc.nextInt();
			    		 while(type2 <1 || type2>3)
			    		 {
			    			accountMenu();
				    		 type2= sc.nextInt();
			    		 }
			    		 System.out.println("Enter amount to transfer");
			    		 amount=sc.nextDouble();
			    		 obj.transfer(amount,type1,type2);
			    		 break;
		    	case 4:
		    		obj.trans.seeAllTransaction();
		    	}
		    	
		    
		    }while(choice!=5);
             
	}
    
    public void transfer(double amount,int type1,int type2)
    {
    
   	 if(type1==1 && type2==2)
   	 {
   		 System.out.print("Checking Account balance before transfer " );
   		 System.out.println(us.getChecking());
   		 System.out.print("Saving Account balance before transfer " );
   		 System.out.println(us.getSaving());
   		 
   		 if(trans.Transfer(us,us.getSaving(), us.getChecking(), amount))
   		 {
   			 System.out.println("Checking Account balance after deposit " +us.getChecking() );
   			 System.out.println("Saving Account balance after transfer " +us.getSaving());
   		 }
   		else
			 System.out.println("Not enough amount to transfer");
   	 }
   	 else if(type1==1 && type2==3)
   	 {
   		System.out.print("Checking Account balance before transfer " );
  		 System.out.println(us.getChecking());
  		 System.out.print("Vacation Account balance before transfer " );
  		 System.out.println(us.getVacation());
  		 
  		 if(trans.Transfer(us,us.getVacation(), us.getChecking(), amount))
  		 {
  			 System.out.println("Checking Account balance after deposit " +us.getChecking() );
  			 System.out.println("Vacation Account balance after transfer " +us.getVacation());
  		 }
  		else
			 System.out.println("Not enough amount to transfer");
   	 }
   	 else if(type1==2 && type2==1)
   	 {
   		
   		 System.out.print("Saving Account balance before transfer " );
   		 System.out.println(us.getSaving());
   		 System.out.print("Checking Account balance before transfer " );
   		 System.out.println(us.getChecking());
   		 
   		 if(trans.Transfer(us, us.getChecking(),us.getSaving(), amount))
   		 {
   		
   			 System.out.println("Saving Account balance after transfer " +us.getSaving());
   			 System.out.println("Checking Account balance after deposit " +us.getChecking() );
   		 }
   		else
			 System.out.println("Not enough amount to transfer");
   	 }
   	 else if(type1==2 && type2==3)
   	 {
   		 System.out.print("Saving Account balance before transfer " );
   		 System.out.println(us.getSaving());
   		 System.out.print("Vacation Account balance before transfer " );
   		 System.out.println(us.getVacation());
   		 
   		 if(trans.Transfer(us, us.getVacation(),us.getSaving(), amount))
   		 {
   		
   			 System.out.println("Saving Account balance after transfer " +us.getSaving());
   			 System.out.println("Vacation Account balance after deposit " +us.getVacation() );
   		 }
   		else
			 System.out.println("Not enough amount to transfer");
   	 }
   	 else if(type1==3 && type2==1)
   	 {
   		
   		 System.out.print("Vacation Account balance before transfer " );
   		 System.out.println(us.getVacation());
   		 System.out.print("Checking Account balance before transfer " );
   		 System.out.println(us.getChecking());
   		 
   		 if(trans.Transfer(us, us.getChecking(),us.getVacation(), amount))
   		 {
   		
   			 System.out.println("Vacation Account balance after transfer " +us.getVacation());
   			 System.out.println("Checking Account balance after deposit " +us.getChecking() );
   		 }
   		else
			 System.out.println("Not enough amount to transfer");
   	 }
   	 else if(type1==3 && type2==2)
   	 {
   		 
   		 System.out.print("Vacation Account balance before transfer " );
   		 System.out.println(us.getVacation());
   		System.out.print("Saving Account balance before transfer " );
  		 System.out.println(us.getSaving());
   		 
   		 if(trans.Transfer(us, us.getSaving(),us.getVacation(), amount))
   		 {
   		
   			System.out.println("Vacation Account balance after deposit " +us.getVacation() );
   			 System.out.println("Saving Account balance after transfer " +us.getSaving());
   			 
   		 }
   		else
			 System.out.println("Not enough amount to transfer");
   	 }
    }
    
    public void deposit(double amount,int type)
    {
   	 System.out.print("Account balance before deposit " );
	 if(type==1)
	 {
		 System.out.println(us.getChecking());
		 trans.Deposit(us,amount, us.getChecking());
		 System.out.println("Account balance after deposit " +us.getChecking() );
	 }
	 else if(type==2)
	 {
		 System.out.println(us.getSaving());
		 trans.Deposit(us,amount, us.getSaving());
		 System.out.println("Account balance after deposit " +us.getSaving() );
	 }
	 else
	 {
		 System.out.println(us.getVacation());
		 trans.Deposit(us,amount, us.getVacation());
		 System.out.println("Account balance after deposit " +us.getVacation() );
	 }
    }
    
    public void Withdraw(double amount,int type)
    {
   	 System.out.print("Account balance before withdraw " );
	 if(type==1)
	 {
		 System.out.println(us.getChecking());
		 if(trans.Withdraw(us,amount, us.getChecking()))
			 System.out.println("Account balance after withdraw " +us.getChecking() );
		 else
			 System.out.println("Not enough amount");
	 }
	 else if(type==2)
	 {
		 System.out.println(us.getSaving());
		 if(trans.Withdraw(us,amount, us.getSaving()))
			 System.out.println("Account balance after withdraw " +us.getSaving() );
		 else
			 System.out.println("Not enough amount");
	 }
	 else
	 {
		 System.out.println(us.getVacation());
		 if(trans.Withdraw(us,amount, us.getVacation()))
			 System.out.println("Account balance after withdraw " +us.getVacation() );
		 else
			 System.out.println("Not enough amount");
	 }
    }
    
    public static void accountMenu()
    {
    	System.out.print("----------------------------\n" +
                "1.\tChecking\n"+
                "2.\tSaving\n"+
                "3.\tVacation\n");
    }
    
    
    public static void printMenu()
	   {
	     System.out.print("Enter your choice\n" +
	                      "----------------------------\n" +
	                      "1.\tDeposit\n"+
	                      "2.\tWithdraw\n"+
	                      "3.\tTransfer\n"+
	                      "4.\tReport Transaction History\n"+
	                      "5.\tQuit\n");
	  }
    
}